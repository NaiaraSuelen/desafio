package com.gft.desafio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesafioMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
