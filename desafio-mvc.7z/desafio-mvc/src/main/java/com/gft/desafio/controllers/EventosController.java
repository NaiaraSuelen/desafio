package com.gft.desafio.controllers;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.gft.desafio.model.entities.Eventos;
import com.gft.desafio.services.CasasShowService;
import com.gft.desafio.services.EventosService;

@Controller
@RequestMapping("/eventos")
public class EventosController {

	private static String caminhoImagem = "C:/Users/NNCE/Workspaces/imagens/";

	@Autowired
	private EventosService eventosService;

	@Autowired
	private CasasShowService casasShowService;

	@RequestMapping(path = "editar")
	public ModelAndView editarCasaShow(@RequestParam(required = false) Long id) {

		ModelAndView mv = new ModelAndView("eventos/form.html");
		Eventos evento;

		if (id == null) {
			evento = new Eventos();
		} else {
			try {
				evento = eventosService.obterEvento(id);
			} catch (Exception e) {
				evento = new Eventos();
				mv.addObject("mensagem", e.getMessage());
			}
		}

		mv.addObject("evento", evento);
		mv.addObject("listaCasasShow", casasShowService.listarCasasShow());

		return mv;
	}

	@RequestMapping(method = RequestMethod.POST, path = "editar")
	public ModelAndView salvarCasaShow(@Valid Eventos evento, @RequestParam("file") MultipartFile arquivo,
			BindingResult bindingResult) {

		ModelAndView mv = new ModelAndView("eventos/form.html");

		boolean novo = true;
	

		if (evento.getId() != null) {
			novo = false;
		}

		if (bindingResult.hasErrors()) {
			mv.addObject("evento", evento);
			return mv;
		}

		eventosService.salvarEvento(evento);

		try {
			if (!arquivo.isEmpty()) {
				byte[] bytes = arquivo.getBytes();
				Path caminho = Paths
						.get(caminhoImagem + String.valueOf(evento.getId()) + arquivo.getOriginalFilename());
				Files.write(caminho, bytes);
				evento.setNomeImagem(String.valueOf(evento.getId()) + arquivo.getOriginalFilename());
				eventosService.salvarEvento(evento);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (novo) {
			mv.addObject("evento", new Eventos());
		} else {
			mv.addObject("evento", evento);
		}

		mv.addObject("mensagem", "Evento salvo com sucesso");
		mv.addObject("listaCasasShow", casasShowService.listarCasasShow());

		return mv;
	}

	@RequestMapping
	public ModelAndView listarEventos() {

		ModelAndView mv = new ModelAndView("eventos/listar.html");

		mv.addObject("lista", eventosService.listarEventos());
		return mv;
	}

	@RequestMapping("/excluir")
	public ModelAndView excluirEvento(@RequestParam Long id, RedirectAttributes redirectAttributes) {

		ModelAndView mv = new ModelAndView("redirect:/eventos");

		try {
			eventosService.deletarEvento(id);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("Erroa ao excluir evento" + e.getMessage());
		}

		return mv;
	}


	@RequestMapping("/mostrarImagem/{imagem}")
	@ResponseBody
	public byte[] retornarImagem(@PathVariable("imagem") String imagem) throws IOException {
		
		File imagemArquivo = new File(caminhoImagem+imagem);
		if(imagem != null || imagem.trim().length() > 0) {
			
			return Files.readAllBytes(imagemArquivo.toPath());
		}
		
		return null;
	}
}
