package com.gft.desafio.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.gft.desafio.services.EventosService;

@Controller
@RequestMapping("/home")
public class PrincipalController {

	@Autowired 
	private EventosService eventosService;
	
	@RequestMapping
	public ModelAndView listarEventos() {
		
		ModelAndView mv = new ModelAndView("home.html");

		mv.addObject("lista", eventosService.listarEventos());
		return mv;
	}

}
