package com.gft.desafio.controllers;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.gft.desafio.model.entities.CasasShow;
import com.gft.desafio.services.CasasShowService;

@Controller
@RequestMapping("/casasShow")
public class CasasShowController {

	@Autowired
	private CasasShowService casasShowService;

	@RequestMapping(path = "editar")
	public ModelAndView editarCasaShow(@RequestParam(required = false) Long id) {

		ModelAndView mv = new ModelAndView("casasShow/form.html");
		CasasShow casaShow;

		if (id == null) {
			casaShow = new CasasShow();
		} else {
			try {
				casaShow = casasShowService.obterCasaShow(id);
			} catch (Exception e) {
				casaShow = new CasasShow();
				mv.addObject("mensagem", e.getMessage());
			}
		}

		mv.addObject("casaShow", casaShow);

		return mv;
	}

	@RequestMapping(method = RequestMethod.POST, path = "editar")
	public ModelAndView salvarCasaShow(@Valid CasasShow casaShow, BindingResult bindingResult) {

		ModelAndView mv = new ModelAndView("casasShow/form.html");

		boolean novo = true;

		if (casaShow.getId() != null) {
			novo = false;
		}

		if (bindingResult.hasErrors()) {
			mv.addObject("casaShow", casaShow);
			return mv;
		}

		casasShowService.salvarCasasShow(casaShow);

		if (novo) {
			mv.addObject("casaShow", new CasasShow());
		} else {
			mv.addObject("casaShow", casaShow);
		}

		mv.addObject("mensagem", "Casa de show salva com sucesso");

		return mv;
	}

	@RequestMapping
	public ModelAndView listarCasasShow() {

		ModelAndView mv = new ModelAndView("casasShow/listar.html");

		mv.addObject("lista", casasShowService.listarCasasShow());
		return mv;
	}

	@RequestMapping("/excluir")
	public ModelAndView excluirCasaShow(@RequestParam Long id, RedirectAttributes redirectAttributes) {

		ModelAndView mv = new ModelAndView("redirect:/casasShow");

		try {
			casasShowService.excluirCasasShow(id);
			redirectAttributes.addFlashAttribute("mensagem", "Casa de show excluída com sucesso.");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("mensagem", "Erro ao excluír casa de show!" + e.getMessage());
		}

		return mv;
	}
	
}
