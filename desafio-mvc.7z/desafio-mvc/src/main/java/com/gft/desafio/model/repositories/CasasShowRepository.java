package com.gft.desafio.model.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gft.desafio.model.entities.CasasShow;

@Repository
public interface CasasShowRepository extends JpaRepository<CasasShow ,Long> {

}
