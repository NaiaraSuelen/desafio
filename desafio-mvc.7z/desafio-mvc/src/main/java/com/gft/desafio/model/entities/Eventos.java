package com.gft.desafio.model.entities;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Eventos {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String nome;

	private int capacidade;

	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date dataEvento;

	private BigDecimal valorIngresso;

	private String generoMusical;
	
	private String nomeImagem;

	@ManyToOne
	private CasasShow casaShow;
	

	public Eventos() {
	}

	public Eventos(String nome, int capacidade, Date dataEvento, BigDecimal valorIngresso, String generoMusical,
			CasasShow casaShow, String imagem) {
		super();
		this.nome = nome;
		this.capacidade = capacidade;
		this.dataEvento = dataEvento;
		this.valorIngresso = valorIngresso;
		this.generoMusical = generoMusical;
		this.casaShow = casaShow;
		this.nomeImagem = imagem;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade(int capacidade) {
		this.capacidade = capacidade;
	}

	public Date getDataEvento() {
		return dataEvento;
	}

	public void setDataEvento(Date dataEvento) {
		this.dataEvento = dataEvento;
	}

	public BigDecimal getValorIngresso() {
		return valorIngresso;
	}

	public void setValorIngresso(BigDecimal valorIngresso) {
		this.valorIngresso = valorIngresso;
	}

	public String getGeneroMusical() {
		return generoMusical;
	}

	public void setGeneroMusical(String generoMusical) {
		this.generoMusical = generoMusical;
	}

	public CasasShow getCasaShow() {
		return casaShow;
	}

	public void setCasaShow(CasasShow casaShow) {
		this.casaShow = casaShow;
	}

	public String getNomeImagem() {
		return nomeImagem;
	}

	public void setNomeImagem(String nomeImagem) {
		this.nomeImagem = nomeImagem;
	}


	
}
