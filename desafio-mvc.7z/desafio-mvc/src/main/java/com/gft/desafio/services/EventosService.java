package com.gft.desafio.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gft.desafio.model.entities.Eventos;
import com.gft.desafio.model.repositories.EventosRepository;

@Service
public class EventosService {

	@Autowired
	private EventosRepository eventosRepository;
	
	public Eventos salvarEvento(Eventos evento) {
		
		eventosRepository.save(evento);
	
		return evento;
	}
	
	public List<Eventos> listarEventos(){
		
		return  eventosRepository.findAll();
	}
	
	public Eventos obterEvento(Long id) throws Exception {
		
		Optional <Eventos> evento = eventosRepository.findById(id);
		
		if(evento.isEmpty()) {
			throw new Exception ("Evento não encontrado");
		}
		
		return evento.get();
	}
	
	public void deletarEvento(Long id) {
		
		eventosRepository.deleteById(id);
	}
	
}
