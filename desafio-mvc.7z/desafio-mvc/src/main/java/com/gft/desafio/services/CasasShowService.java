package com.gft.desafio.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gft.desafio.model.entities.CasasShow;
import com.gft.desafio.model.repositories.CasasShowRepository;

@Service
public class CasasShowService {

	@Autowired
	CasasShowRepository casasShowRepository;

	public CasasShow salvarCasasShow(CasasShow casaShow) {

		return casasShowRepository.save(casaShow);
	}

	public List<CasasShow> listarCasasShow() {

		return casasShowRepository.findAll();
	}

	public CasasShow obterCasaShow(Long id) throws Exception {

		Optional<CasasShow> casaShow = casasShowRepository.findById(id);

		if (casaShow.isEmpty()) {
			throw new Exception("Casa de show não encontrada.");
		}

		return casaShow.get();
	}

	public void excluirCasasShow(Long id) {

		casasShowRepository.deleteById(id);
	}
}
