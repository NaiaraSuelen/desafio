package com.gft.desafio;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.gft.desafio.model.entities.CasasShow;
import com.gft.desafio.model.entities.Eventos;
import com.gft.desafio.model.repositories.CasasShowRepository;
import com.gft.desafio.services.CasasShowService;

@Component
@Transactional
public class PopulaçãoInicialBanco implements CommandLineRunner {

	@Autowired
	private CasasShowRepository casasShowRepository;

	@Autowired
	private CasasShowService casasShowService;

	@Override
	public void run(String... args) throws Exception {

		CasasShow c1 = new CasasShow("Pagliato", "Est. gulis");
		CasasShow c2 = new CasasShow("Deck", "Rua kwjsks");
		CasasShow c3 = new CasasShow("Vegas", "Rua declat");

		if (casasShowService.listarCasasShow().isEmpty()) {
			casasShowRepository.save(c1);
			casasShowRepository.save(c2);
			casasShowRepository.save(c3);
		}
	
	}
}
